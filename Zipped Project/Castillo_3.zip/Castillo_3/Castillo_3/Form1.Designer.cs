﻿namespace Castillo_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.balloonsPictureBox = new System.Windows.Forms.PictureBox();
            this.companyNameLabel = new System.Windows.Forms.Label();
            this.customerInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.stateMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.streetTextBox = new System.Windows.Forms.TextBox();
            this.phoneNumberLabel = new System.Windows.Forms.Label();
            this.phoneNumberMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.zipCodeMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.titleComboBox = new System.Windows.Forms.ComboBox();
            this.zipCodeLabel = new System.Windows.Forms.Label();
            this.stateLabel = new System.Windows.Forms.Label();
            this.cityLabel = new System.Windows.Forms.Label();
            this.streetLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.deliveryInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.homeDeliveryUpchargeLabel = new System.Windows.Forms.Label();
            this.homeDeliveryRadioButton = new System.Windows.Forms.RadioButton();
            this.storePickUpRadioButton = new System.Windows.Forms.RadioButton();
            this.deliveryTypeLabel = new System.Windows.Forms.Label();
            this.deliveryDateLabel = new System.Windows.Forms.Label();
            this.deliveryDateMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.orderDetailsGroupBox = new System.Windows.Forms.GroupBox();
            this.coffeeMugPriceLabel = new System.Windows.Forms.Label();
            this.flowerArrangementPriceLabel = new System.Windows.Forms.Label();
            this.jarOfJellyBeansPriceLabel = new System.Windows.Forms.Label();
            this.pottedPlantPriceLabel = new System.Windows.Forms.Label();
            this.taxRateLabel = new System.Windows.Forms.Label();
            this.salesTaxAmountLabel = new System.Windows.Forms.Label();
            this.orderTotalLabel = new System.Windows.Forms.Label();
            this.orderSubtotalLabel = new System.Windows.Forms.Label();
            this.orderSubtotalLblLabel = new System.Windows.Forms.Label();
            this.salesTaxAmountLblLabel = new System.Windows.Forms.Label();
            this.orderTotalLblLabel = new System.Windows.Forms.Label();
            this.boxOfChocolatesPriceLabel = new System.Windows.Forms.Label();
            this.personalizedMessageTextBox = new System.Windows.Forms.TextBox();
            this.personalizedMessageInstructionLabel = new System.Windows.Forms.Label();
            this.personalizedMessagePriceLabel = new System.Windows.Forms.Label();
            this.personalizedMessageCheckBox = new System.Windows.Forms.CheckBox();
            this.personalizedMessageLabel = new System.Windows.Forms.Label();
            this.extrasLabel = new System.Windows.Forms.Label();
            this.extrasListBox = new System.Windows.Forms.ListBox();
            this.specialOccasionLabel = new System.Windows.Forms.Label();
            this.specialOccasionComboBox = new System.Windows.Forms.ComboBox();
            this.dozenBundleCostLabel = new System.Windows.Forms.Label();
            this.halfDozenBundleCostLabel = new System.Windows.Forms.Label();
            this.singleBundleCostLabel = new System.Windows.Forms.Label();
            this.halfDozenBundleRadioButton = new System.Windows.Forms.RadioButton();
            this.dozenBundleRadioButton = new System.Windows.Forms.RadioButton();
            this.singleBundleRadioButton = new System.Windows.Forms.RadioButton();
            this.bundleSizeLabel = new System.Windows.Forms.Label();
            this.displaySummaryButton = new System.Windows.Forms.Button();
            this.clearFormButton = new System.Windows.Forms.Button();
            this.exitProgramButton = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.balloonsPictureBox)).BeginInit();
            this.customerInfoGroupBox.SuspendLayout();
            this.deliveryInfoGroupBox.SuspendLayout();
            this.orderDetailsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // balloonsPictureBox
            // 
            this.balloonsPictureBox.Image = global::Castillo_3.Properties.Resources.balloonsImage;
            this.balloonsPictureBox.Location = new System.Drawing.Point(0, 0);
            this.balloonsPictureBox.Name = "balloonsPictureBox";
            this.balloonsPictureBox.Size = new System.Drawing.Size(341, 122);
            this.balloonsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.balloonsPictureBox.TabIndex = 0;
            this.balloonsPictureBox.TabStop = false;
            // 
            // companyNameLabel
            // 
            this.companyNameLabel.BackColor = System.Drawing.SystemColors.MenuBar;
            this.companyNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.companyNameLabel.Font = new System.Drawing.Font("Monotype Corsiva", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.companyNameLabel.Location = new System.Drawing.Point(57, 88);
            this.companyNameLabel.Name = "companyNameLabel";
            this.companyNameLabel.Size = new System.Drawing.Size(206, 34);
            this.companyNameLabel.TabIndex = 0;
            this.companyNameLabel.Text = "Bonnie\'s Balloons";
            this.companyNameLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // customerInfoGroupBox
            // 
            this.customerInfoGroupBox.Controls.Add(this.cityTextBox);
            this.customerInfoGroupBox.Controls.Add(this.stateMaskedTextBox);
            this.customerInfoGroupBox.Controls.Add(this.streetTextBox);
            this.customerInfoGroupBox.Controls.Add(this.phoneNumberLabel);
            this.customerInfoGroupBox.Controls.Add(this.phoneNumberMaskedTextBox);
            this.customerInfoGroupBox.Controls.Add(this.zipCodeMaskedTextBox);
            this.customerInfoGroupBox.Controls.Add(this.lastNameTextBox);
            this.customerInfoGroupBox.Controls.Add(this.firstNameTextBox);
            this.customerInfoGroupBox.Controls.Add(this.titleComboBox);
            this.customerInfoGroupBox.Controls.Add(this.zipCodeLabel);
            this.customerInfoGroupBox.Controls.Add(this.stateLabel);
            this.customerInfoGroupBox.Controls.Add(this.cityLabel);
            this.customerInfoGroupBox.Controls.Add(this.streetLabel);
            this.customerInfoGroupBox.Controls.Add(this.titleLabel);
            this.customerInfoGroupBox.Controls.Add(this.lastNameLabel);
            this.customerInfoGroupBox.Controls.Add(this.firstNameLabel);
            this.customerInfoGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerInfoGroupBox.Location = new System.Drawing.Point(0, 128);
            this.customerInfoGroupBox.Name = "customerInfoGroupBox";
            this.customerInfoGroupBox.Size = new System.Drawing.Size(317, 124);
            this.customerInfoGroupBox.TabIndex = 1;
            this.customerInfoGroupBox.TabStop = false;
            this.customerInfoGroupBox.Text = "Customer Information";
            // 
            // cityTextBox
            // 
            this.cityTextBox.Location = new System.Drawing.Point(143, 88);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(57, 20);
            this.cityTextBox.TabIndex = 11;
            // 
            // stateMaskedTextBox
            // 
            this.stateMaskedTextBox.Location = new System.Drawing.Point(211, 88);
            this.stateMaskedTextBox.Mask = "LL";
            this.stateMaskedTextBox.Name = "stateMaskedTextBox";
            this.stateMaskedTextBox.Size = new System.Drawing.Size(21, 20);
            this.stateMaskedTextBox.TabIndex = 13;
            // 
            // streetTextBox
            // 
            this.streetTextBox.Location = new System.Drawing.Point(6, 88);
            this.streetTextBox.Name = "streetTextBox";
            this.streetTextBox.Size = new System.Drawing.Size(128, 20);
            this.streetTextBox.TabIndex = 9;
            // 
            // phoneNumberLabel
            // 
            this.phoneNumberLabel.AutoSize = true;
            this.phoneNumberLabel.Location = new System.Drawing.Point(229, 22);
            this.phoneNumberLabel.Name = "phoneNumberLabel";
            this.phoneNumberLabel.Size = new System.Drawing.Size(78, 13);
            this.phoneNumberLabel.TabIndex = 6;
            this.phoneNumberLabel.Text = "Phone Number";
            // 
            // phoneNumberMaskedTextBox
            // 
            this.phoneNumberMaskedTextBox.Location = new System.Drawing.Point(227, 38);
            this.phoneNumberMaskedTextBox.Mask = "(999) 000-0000";
            this.phoneNumberMaskedTextBox.Name = "phoneNumberMaskedTextBox";
            this.phoneNumberMaskedTextBox.Size = new System.Drawing.Size(80, 20);
            this.phoneNumberMaskedTextBox.TabIndex = 7;
            // 
            // zipCodeMaskedTextBox
            // 
            this.zipCodeMaskedTextBox.Location = new System.Drawing.Point(249, 88);
            this.zipCodeMaskedTextBox.Mask = "00000";
            this.zipCodeMaskedTextBox.Name = "zipCodeMaskedTextBox";
            this.zipCodeMaskedTextBox.Size = new System.Drawing.Size(39, 20);
            this.zipCodeMaskedTextBox.TabIndex = 15;
            this.zipCodeMaskedTextBox.ValidatingType = typeof(int);
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(142, 36);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(74, 20);
            this.lastNameTextBox.TabIndex = 5;
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(60, 37);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(74, 20);
            this.firstNameTextBox.TabIndex = 3;
            // 
            // titleComboBox
            // 
            this.titleComboBox.FormattingEnabled = true;
            this.titleComboBox.Items.AddRange(new object[] {
            "Dr.",
            "Mr.",
            "Mrs.",
            "Ms.",
            "Rev."});
            this.titleComboBox.Location = new System.Drawing.Point(6, 36);
            this.titleComboBox.Name = "titleComboBox";
            this.titleComboBox.Size = new System.Drawing.Size(46, 21);
            this.titleComboBox.TabIndex = 1;
            // 
            // zipCodeLabel
            // 
            this.zipCodeLabel.AutoSize = true;
            this.zipCodeLabel.Location = new System.Drawing.Point(245, 72);
            this.zipCodeLabel.Name = "zipCodeLabel";
            this.zipCodeLabel.Size = new System.Drawing.Size(50, 13);
            this.zipCodeLabel.TabIndex = 14;
            this.zipCodeLabel.Text = "Zip Code";
            // 
            // stateLabel
            // 
            this.stateLabel.AutoSize = true;
            this.stateLabel.Location = new System.Drawing.Point(206, 72);
            this.stateLabel.Name = "stateLabel";
            this.stateLabel.Size = new System.Drawing.Size(32, 13);
            this.stateLabel.TabIndex = 12;
            this.stateLabel.Text = "State";
            // 
            // cityLabel
            // 
            this.cityLabel.AutoSize = true;
            this.cityLabel.Location = new System.Drawing.Point(157, 72);
            this.cityLabel.Name = "cityLabel";
            this.cityLabel.Size = new System.Drawing.Size(24, 13);
            this.cityLabel.TabIndex = 10;
            this.cityLabel.Text = "City";
            // 
            // streetLabel
            // 
            this.streetLabel.AutoSize = true;
            this.streetLabel.Location = new System.Drawing.Point(7, 72);
            this.streetLabel.Name = "streetLabel";
            this.streetLabel.Size = new System.Drawing.Size(76, 13);
            this.streetLabel.TabIndex = 8;
            this.streetLabel.Text = "Street Address";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(12, 22);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(27, 13);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Title";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(151, 22);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(58, 13);
            this.lastNameLabel.TabIndex = 4;
            this.lastNameLabel.Text = "Last Name";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(69, 22);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(57, 13);
            this.firstNameLabel.TabIndex = 2;
            this.firstNameLabel.Text = "First Name";
            // 
            // deliveryInfoGroupBox
            // 
            this.deliveryInfoGroupBox.Controls.Add(this.homeDeliveryUpchargeLabel);
            this.deliveryInfoGroupBox.Controls.Add(this.homeDeliveryRadioButton);
            this.deliveryInfoGroupBox.Controls.Add(this.storePickUpRadioButton);
            this.deliveryInfoGroupBox.Controls.Add(this.deliveryTypeLabel);
            this.deliveryInfoGroupBox.Controls.Add(this.deliveryDateLabel);
            this.deliveryInfoGroupBox.Controls.Add(this.deliveryDateMaskedTextBox);
            this.deliveryInfoGroupBox.Location = new System.Drawing.Point(0, 258);
            this.deliveryInfoGroupBox.Name = "deliveryInfoGroupBox";
            this.deliveryInfoGroupBox.Size = new System.Drawing.Size(307, 94);
            this.deliveryInfoGroupBox.TabIndex = 2;
            this.deliveryInfoGroupBox.TabStop = false;
            this.deliveryInfoGroupBox.Text = "Delivery Information";
            // 
            // homeDeliveryUpchargeLabel
            // 
            this.homeDeliveryUpchargeLabel.AutoSize = true;
            this.homeDeliveryUpchargeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeDeliveryUpchargeLabel.Location = new System.Drawing.Point(215, 65);
            this.homeDeliveryUpchargeLabel.Name = "homeDeliveryUpchargeLabel";
            this.homeDeliveryUpchargeLabel.Size = new System.Drawing.Size(19, 13);
            this.homeDeliveryUpchargeLabel.TabIndex = 5;
            this.homeDeliveryUpchargeLabel.Text = "$$";
            this.homeDeliveryUpchargeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // homeDeliveryRadioButton
            // 
            this.homeDeliveryRadioButton.AutoSize = true;
            this.homeDeliveryRadioButton.Location = new System.Drawing.Point(127, 61);
            this.homeDeliveryRadioButton.Name = "homeDeliveryRadioButton";
            this.homeDeliveryRadioButton.Size = new System.Drawing.Size(94, 17);
            this.homeDeliveryRadioButton.TabIndex = 4;
            this.homeDeliveryRadioButton.Text = "Home Delivery";
            this.homeDeliveryRadioButton.UseVisualStyleBackColor = true;
            // 
            // storePickUpRadioButton
            // 
            this.storePickUpRadioButton.AutoSize = true;
            this.storePickUpRadioButton.Checked = true;
            this.storePickUpRadioButton.Location = new System.Drawing.Point(127, 38);
            this.storePickUpRadioButton.Name = "storePickUpRadioButton";
            this.storePickUpRadioButton.Size = new System.Drawing.Size(91, 17);
            this.storePickUpRadioButton.TabIndex = 3;
            this.storePickUpRadioButton.TabStop = true;
            this.storePickUpRadioButton.Text = "Store Pick-Up";
            this.storePickUpRadioButton.UseVisualStyleBackColor = true;
            this.storePickUpRadioButton.CheckedChanged += new System.EventHandler(this.storePickUpRadioButton_CheckedChanged);
            // 
            // deliveryTypeLabel
            // 
            this.deliveryTypeLabel.AutoSize = true;
            this.deliveryTypeLabel.Location = new System.Drawing.Point(123, 22);
            this.deliveryTypeLabel.Name = "deliveryTypeLabel";
            this.deliveryTypeLabel.Size = new System.Drawing.Size(72, 13);
            this.deliveryTypeLabel.TabIndex = 2;
            this.deliveryTypeLabel.Text = "Delivery Type";
            // 
            // deliveryDateLabel
            // 
            this.deliveryDateLabel.AutoSize = true;
            this.deliveryDateLabel.Location = new System.Drawing.Point(7, 22);
            this.deliveryDateLabel.Name = "deliveryDateLabel";
            this.deliveryDateLabel.Size = new System.Drawing.Size(71, 13);
            this.deliveryDateLabel.TabIndex = 0;
            this.deliveryDateLabel.Text = "Delivery Date";
            // 
            // deliveryDateMaskedTextBox
            // 
            this.deliveryDateMaskedTextBox.Location = new System.Drawing.Point(10, 38);
            this.deliveryDateMaskedTextBox.Mask = "00/00/0000";
            this.deliveryDateMaskedTextBox.Name = "deliveryDateMaskedTextBox";
            this.deliveryDateMaskedTextBox.Size = new System.Drawing.Size(65, 20);
            this.deliveryDateMaskedTextBox.TabIndex = 1;
            this.deliveryDateMaskedTextBox.ValidatingType = typeof(System.DateTime);
            // 
            // orderDetailsGroupBox
            // 
            this.orderDetailsGroupBox.Controls.Add(this.coffeeMugPriceLabel);
            this.orderDetailsGroupBox.Controls.Add(this.flowerArrangementPriceLabel);
            this.orderDetailsGroupBox.Controls.Add(this.jarOfJellyBeansPriceLabel);
            this.orderDetailsGroupBox.Controls.Add(this.pottedPlantPriceLabel);
            this.orderDetailsGroupBox.Controls.Add(this.taxRateLabel);
            this.orderDetailsGroupBox.Controls.Add(this.salesTaxAmountLabel);
            this.orderDetailsGroupBox.Controls.Add(this.orderTotalLabel);
            this.orderDetailsGroupBox.Controls.Add(this.orderSubtotalLabel);
            this.orderDetailsGroupBox.Controls.Add(this.orderSubtotalLblLabel);
            this.orderDetailsGroupBox.Controls.Add(this.salesTaxAmountLblLabel);
            this.orderDetailsGroupBox.Controls.Add(this.orderTotalLblLabel);
            this.orderDetailsGroupBox.Controls.Add(this.boxOfChocolatesPriceLabel);
            this.orderDetailsGroupBox.Controls.Add(this.personalizedMessageTextBox);
            this.orderDetailsGroupBox.Controls.Add(this.personalizedMessageInstructionLabel);
            this.orderDetailsGroupBox.Controls.Add(this.personalizedMessagePriceLabel);
            this.orderDetailsGroupBox.Controls.Add(this.personalizedMessageCheckBox);
            this.orderDetailsGroupBox.Controls.Add(this.personalizedMessageLabel);
            this.orderDetailsGroupBox.Controls.Add(this.extrasLabel);
            this.orderDetailsGroupBox.Controls.Add(this.extrasListBox);
            this.orderDetailsGroupBox.Controls.Add(this.specialOccasionLabel);
            this.orderDetailsGroupBox.Controls.Add(this.specialOccasionComboBox);
            this.orderDetailsGroupBox.Controls.Add(this.dozenBundleCostLabel);
            this.orderDetailsGroupBox.Controls.Add(this.halfDozenBundleCostLabel);
            this.orderDetailsGroupBox.Controls.Add(this.singleBundleCostLabel);
            this.orderDetailsGroupBox.Controls.Add(this.halfDozenBundleRadioButton);
            this.orderDetailsGroupBox.Controls.Add(this.dozenBundleRadioButton);
            this.orderDetailsGroupBox.Controls.Add(this.singleBundleRadioButton);
            this.orderDetailsGroupBox.Controls.Add(this.bundleSizeLabel);
            this.orderDetailsGroupBox.Location = new System.Drawing.Point(0, 358);
            this.orderDetailsGroupBox.Name = "orderDetailsGroupBox";
            this.orderDetailsGroupBox.Size = new System.Drawing.Size(307, 298);
            this.orderDetailsGroupBox.TabIndex = 3;
            this.orderDetailsGroupBox.TabStop = false;
            this.orderDetailsGroupBox.Text = "Order Details";
            // 
            // coffeeMugPriceLabel
            // 
            this.coffeeMugPriceLabel.AutoSize = true;
            this.coffeeMugPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coffeeMugPriceLabel.Location = new System.Drawing.Point(261, 90);
            this.coffeeMugPriceLabel.Name = "coffeeMugPriceLabel";
            this.coffeeMugPriceLabel.Size = new System.Drawing.Size(19, 13);
            this.coffeeMugPriceLabel.TabIndex = 12;
            this.coffeeMugPriceLabel.Text = "$$";
            this.coffeeMugPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // flowerArrangementPriceLabel
            // 
            this.flowerArrangementPriceLabel.AutoSize = true;
            this.flowerArrangementPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowerArrangementPriceLabel.Location = new System.Drawing.Point(261, 103);
            this.flowerArrangementPriceLabel.Name = "flowerArrangementPriceLabel";
            this.flowerArrangementPriceLabel.Size = new System.Drawing.Size(19, 13);
            this.flowerArrangementPriceLabel.TabIndex = 13;
            this.flowerArrangementPriceLabel.Text = "$$";
            this.flowerArrangementPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // jarOfJellyBeansPriceLabel
            // 
            this.jarOfJellyBeansPriceLabel.AutoSize = true;
            this.jarOfJellyBeansPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jarOfJellyBeansPriceLabel.Location = new System.Drawing.Point(261, 117);
            this.jarOfJellyBeansPriceLabel.Name = "jarOfJellyBeansPriceLabel";
            this.jarOfJellyBeansPriceLabel.Size = new System.Drawing.Size(19, 13);
            this.jarOfJellyBeansPriceLabel.TabIndex = 14;
            this.jarOfJellyBeansPriceLabel.Text = "$$";
            this.jarOfJellyBeansPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pottedPlantPriceLabel
            // 
            this.pottedPlantPriceLabel.AutoSize = true;
            this.pottedPlantPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pottedPlantPriceLabel.Location = new System.Drawing.Point(261, 130);
            this.pottedPlantPriceLabel.Name = "pottedPlantPriceLabel";
            this.pottedPlantPriceLabel.Size = new System.Drawing.Size(19, 13);
            this.pottedPlantPriceLabel.TabIndex = 15;
            this.pottedPlantPriceLabel.Text = "$$";
            this.pottedPlantPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // taxRateLabel
            // 
            this.taxRateLabel.AutoSize = true;
            this.taxRateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxRateLabel.Location = new System.Drawing.Point(165, 242);
            this.taxRateLabel.Name = "taxRateLabel";
            this.taxRateLabel.Size = new System.Drawing.Size(26, 13);
            this.taxRateLabel.TabIndex = 25;
            this.taxRateLabel.Text = "TAX";
            this.taxRateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // salesTaxAmountLabel
            // 
            this.salesTaxAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salesTaxAmountLabel.Location = new System.Drawing.Point(126, 259);
            this.salesTaxAmountLabel.Name = "salesTaxAmountLabel";
            this.salesTaxAmountLabel.Size = new System.Drawing.Size(52, 23);
            this.salesTaxAmountLabel.TabIndex = 24;
            this.salesTaxAmountLabel.Text = "$$";
            this.salesTaxAmountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // orderTotalLabel
            // 
            this.orderTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.orderTotalLabel.Location = new System.Drawing.Point(227, 259);
            this.orderTotalLabel.Name = "orderTotalLabel";
            this.orderTotalLabel.Size = new System.Drawing.Size(52, 23);
            this.orderTotalLabel.TabIndex = 27;
            this.orderTotalLabel.Text = "$$";
            this.orderTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // orderSubtotalLabel
            // 
            this.orderSubtotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.orderSubtotalLabel.Location = new System.Drawing.Point(25, 259);
            this.orderSubtotalLabel.Name = "orderSubtotalLabel";
            this.orderSubtotalLabel.Size = new System.Drawing.Size(52, 23);
            this.orderSubtotalLabel.TabIndex = 22;
            this.orderSubtotalLabel.Text = "$$";
            this.orderSubtotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // orderSubtotalLblLabel
            // 
            this.orderSubtotalLblLabel.AutoSize = true;
            this.orderSubtotalLblLabel.Location = new System.Drawing.Point(30, 242);
            this.orderSubtotalLblLabel.Name = "orderSubtotalLblLabel";
            this.orderSubtotalLblLabel.Size = new System.Drawing.Size(46, 13);
            this.orderSubtotalLblLabel.TabIndex = 21;
            this.orderSubtotalLblLabel.Text = "Subtotal";
            // 
            // salesTaxAmountLblLabel
            // 
            this.salesTaxAmountLblLabel.AutoSize = true;
            this.salesTaxAmountLblLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salesTaxAmountLblLabel.Location = new System.Drawing.Point(115, 242);
            this.salesTaxAmountLblLabel.Name = "salesTaxAmountLblLabel";
            this.salesTaxAmountLblLabel.Size = new System.Drawing.Size(54, 13);
            this.salesTaxAmountLblLabel.TabIndex = 23;
            this.salesTaxAmountLblLabel.Text = "Sales Tax";
            // 
            // orderTotalLblLabel
            // 
            this.orderTotalLblLabel.AutoSize = true;
            this.orderTotalLblLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderTotalLblLabel.Location = new System.Drawing.Point(223, 242);
            this.orderTotalLblLabel.Name = "orderTotalLblLabel";
            this.orderTotalLblLabel.Size = new System.Drawing.Size(60, 13);
            this.orderTotalLblLabel.TabIndex = 26;
            this.orderTotalLblLabel.Text = "Order Total";
            // 
            // boxOfChocolatesPriceLabel
            // 
            this.boxOfChocolatesPriceLabel.AutoSize = true;
            this.boxOfChocolatesPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boxOfChocolatesPriceLabel.Location = new System.Drawing.Point(261, 77);
            this.boxOfChocolatesPriceLabel.Name = "boxOfChocolatesPriceLabel";
            this.boxOfChocolatesPriceLabel.Size = new System.Drawing.Size(19, 13);
            this.boxOfChocolatesPriceLabel.TabIndex = 11;
            this.boxOfChocolatesPriceLabel.Text = "$$";
            this.boxOfChocolatesPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // personalizedMessageTextBox
            // 
            this.personalizedMessageTextBox.Enabled = false;
            this.personalizedMessageTextBox.Location = new System.Drawing.Point(10, 211);
            this.personalizedMessageTextBox.MaxLength = 30;
            this.personalizedMessageTextBox.Name = "personalizedMessageTextBox";
            this.personalizedMessageTextBox.Size = new System.Drawing.Size(206, 20);
            this.personalizedMessageTextBox.TabIndex = 20;
            // 
            // personalizedMessageInstructionLabel
            // 
            this.personalizedMessageInstructionLabel.Enabled = false;
            this.personalizedMessageInstructionLabel.Location = new System.Drawing.Point(10, 177);
            this.personalizedMessageInstructionLabel.Name = "personalizedMessageInstructionLabel";
            this.personalizedMessageInstructionLabel.Size = new System.Drawing.Size(295, 30);
            this.personalizedMessageInstructionLabel.TabIndex = 19;
            this.personalizedMessageInstructionLabel.Text = "Type the message to be printed on a customized card. (Message must be limited to " +
    "30 characters) :";
            // 
            // personalizedMessagePriceLabel
            // 
            this.personalizedMessagePriceLabel.AutoSize = true;
            this.personalizedMessagePriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.personalizedMessagePriceLabel.Location = new System.Drawing.Point(253, 157);
            this.personalizedMessagePriceLabel.Name = "personalizedMessagePriceLabel";
            this.personalizedMessagePriceLabel.Size = new System.Drawing.Size(19, 13);
            this.personalizedMessagePriceLabel.TabIndex = 18;
            this.personalizedMessagePriceLabel.Text = "$$";
            this.personalizedMessagePriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // personalizedMessageCheckBox
            // 
            this.personalizedMessageCheckBox.Location = new System.Drawing.Point(13, 151);
            this.personalizedMessageCheckBox.Name = "personalizedMessageCheckBox";
            this.personalizedMessageCheckBox.Size = new System.Drawing.Size(249, 24);
            this.personalizedMessageCheckBox.TabIndex = 17;
            this.personalizedMessageCheckBox.Text = "Yes, I want to include a personalized message!";
            this.personalizedMessageCheckBox.UseVisualStyleBackColor = true;
            this.personalizedMessageCheckBox.CheckedChanged += new System.EventHandler(this.personalizedMessageCheckBox_CheckedChanged);
            // 
            // personalizedMessageLabel
            // 
            this.personalizedMessageLabel.AutoSize = true;
            this.personalizedMessageLabel.Location = new System.Drawing.Point(12, 133);
            this.personalizedMessageLabel.Name = "personalizedMessageLabel";
            this.personalizedMessageLabel.Size = new System.Drawing.Size(113, 13);
            this.personalizedMessageLabel.TabIndex = 16;
            this.personalizedMessageLabel.Text = "Personalized Message";
            // 
            // extrasLabel
            // 
            this.extrasLabel.AutoSize = true;
            this.extrasLabel.Location = new System.Drawing.Point(152, 61);
            this.extrasLabel.Name = "extrasLabel";
            this.extrasLabel.Size = new System.Drawing.Size(84, 13);
            this.extrasLabel.TabIndex = 9;
            this.extrasLabel.Text = "Extras (Optional)";
            // 
            // extrasListBox
            // 
            this.extrasListBox.FormattingEnabled = true;
            this.extrasListBox.Location = new System.Drawing.Point(155, 77);
            this.extrasListBox.Name = "extrasListBox";
            this.extrasListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.extrasListBox.Size = new System.Drawing.Size(105, 69);
            this.extrasListBox.Sorted = true;
            this.extrasListBox.TabIndex = 10;
            this.extrasListBox.SelectedIndexChanged += new System.EventHandler(this.extrasListBox_SelectedIndexChanged);
            // 
            // specialOccasionLabel
            // 
            this.specialOccasionLabel.AutoSize = true;
            this.specialOccasionLabel.Location = new System.Drawing.Point(152, 20);
            this.specialOccasionLabel.Name = "specialOccasionLabel";
            this.specialOccasionLabel.Size = new System.Drawing.Size(90, 13);
            this.specialOccasionLabel.TabIndex = 7;
            this.specialOccasionLabel.Text = "Special Occasion";
            // 
            // specialOccasionComboBox
            // 
            this.specialOccasionComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.specialOccasionComboBox.FormattingEnabled = true;
            this.specialOccasionComboBox.Location = new System.Drawing.Point(155, 36);
            this.specialOccasionComboBox.Name = "specialOccasionComboBox";
            this.specialOccasionComboBox.Size = new System.Drawing.Size(105, 21);
            this.specialOccasionComboBox.Sorted = true;
            this.specialOccasionComboBox.TabIndex = 8;
            // 
            // dozenBundleCostLabel
            // 
            this.dozenBundleCostLabel.AutoSize = true;
            this.dozenBundleCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dozenBundleCostLabel.Location = new System.Drawing.Point(62, 92);
            this.dozenBundleCostLabel.Name = "dozenBundleCostLabel";
            this.dozenBundleCostLabel.Size = new System.Drawing.Size(19, 13);
            this.dozenBundleCostLabel.TabIndex = 6;
            this.dozenBundleCostLabel.Text = "$$";
            this.dozenBundleCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // halfDozenBundleCostLabel
            // 
            this.halfDozenBundleCostLabel.AutoSize = true;
            this.halfDozenBundleCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.halfDozenBundleCostLabel.Location = new System.Drawing.Point(85, 69);
            this.halfDozenBundleCostLabel.Name = "halfDozenBundleCostLabel";
            this.halfDozenBundleCostLabel.Size = new System.Drawing.Size(19, 13);
            this.halfDozenBundleCostLabel.TabIndex = 4;
            this.halfDozenBundleCostLabel.Text = "$$";
            this.halfDozenBundleCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // singleBundleCostLabel
            // 
            this.singleBundleCostLabel.AutoSize = true;
            this.singleBundleCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.singleBundleCostLabel.Location = new System.Drawing.Point(61, 46);
            this.singleBundleCostLabel.Name = "singleBundleCostLabel";
            this.singleBundleCostLabel.Size = new System.Drawing.Size(19, 13);
            this.singleBundleCostLabel.TabIndex = 2;
            this.singleBundleCostLabel.Text = "$$";
            this.singleBundleCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // halfDozenBundleRadioButton
            // 
            this.halfDozenBundleRadioButton.AutoSize = true;
            this.halfDozenBundleRadioButton.Location = new System.Drawing.Point(13, 65);
            this.halfDozenBundleRadioButton.Name = "halfDozenBundleRadioButton";
            this.halfDozenBundleRadioButton.Size = new System.Drawing.Size(78, 17);
            this.halfDozenBundleRadioButton.TabIndex = 3;
            this.halfDozenBundleRadioButton.Text = "Half-Dozen";
            this.halfDozenBundleRadioButton.UseVisualStyleBackColor = true;
            this.halfDozenBundleRadioButton.CheckedChanged += new System.EventHandler(this.halfDozenBundleRadioButton_CheckedChanged);
            // 
            // dozenBundleRadioButton
            // 
            this.dozenBundleRadioButton.AutoSize = true;
            this.dozenBundleRadioButton.Location = new System.Drawing.Point(13, 88);
            this.dozenBundleRadioButton.Name = "dozenBundleRadioButton";
            this.dozenBundleRadioButton.Size = new System.Drawing.Size(56, 17);
            this.dozenBundleRadioButton.TabIndex = 5;
            this.dozenBundleRadioButton.Text = "Dozen";
            this.dozenBundleRadioButton.UseVisualStyleBackColor = true;
            // 
            // singleBundleRadioButton
            // 
            this.singleBundleRadioButton.AutoSize = true;
            this.singleBundleRadioButton.Checked = true;
            this.singleBundleRadioButton.Location = new System.Drawing.Point(13, 42);
            this.singleBundleRadioButton.Name = "singleBundleRadioButton";
            this.singleBundleRadioButton.Size = new System.Drawing.Size(54, 17);
            this.singleBundleRadioButton.TabIndex = 1;
            this.singleBundleRadioButton.TabStop = true;
            this.singleBundleRadioButton.Text = "Single";
            this.singleBundleRadioButton.UseVisualStyleBackColor = true;
            this.singleBundleRadioButton.CheckedChanged += new System.EventHandler(this.singleBundleRadioButton_CheckedChanged);
            // 
            // bundleSizeLabel
            // 
            this.bundleSizeLabel.AutoSize = true;
            this.bundleSizeLabel.Location = new System.Drawing.Point(10, 20);
            this.bundleSizeLabel.Name = "bundleSizeLabel";
            this.bundleSizeLabel.Size = new System.Drawing.Size(63, 13);
            this.bundleSizeLabel.TabIndex = 0;
            this.bundleSizeLabel.Text = "Bundle Size";
            // 
            // displaySummaryButton
            // 
            this.displaySummaryButton.Location = new System.Drawing.Point(7, 662);
            this.displaySummaryButton.Name = "displaySummaryButton";
            this.displaySummaryButton.Size = new System.Drawing.Size(96, 32);
            this.displaySummaryButton.TabIndex = 4;
            this.displaySummaryButton.Text = "Display &Summary";
            this.toolTip1.SetToolTip(this.displaySummaryButton, "Display entire contents of order");
            this.displaySummaryButton.UseVisualStyleBackColor = true;
            this.displaySummaryButton.Click += new System.EventHandler(this.displaySummaryButton_Click);
            // 
            // clearFormButton
            // 
            this.clearFormButton.Location = new System.Drawing.Point(109, 662);
            this.clearFormButton.Name = "clearFormButton";
            this.clearFormButton.Size = new System.Drawing.Size(96, 32);
            this.clearFormButton.TabIndex = 5;
            this.clearFormButton.Text = "&Clear Form";
            this.toolTip1.SetToolTip(this.clearFormButton, "Resets the form");
            this.clearFormButton.UseVisualStyleBackColor = true;
            this.clearFormButton.Click += new System.EventHandler(this.clearFormButton_Click);
            // 
            // exitProgramButton
            // 
            this.exitProgramButton.Location = new System.Drawing.Point(212, 662);
            this.exitProgramButton.Name = "exitProgramButton";
            this.exitProgramButton.Size = new System.Drawing.Size(96, 32);
            this.exitProgramButton.TabIndex = 6;
            this.exitProgramButton.Text = "E&xit Program";
            this.toolTip1.SetToolTip(this.exitProgramButton, "Closes the program");
            this.exitProgramButton.UseVisualStyleBackColor = true;
            this.exitProgramButton.Click += new System.EventHandler(this.exitProgramButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(316, 701);
            this.Controls.Add(this.exitProgramButton);
            this.Controls.Add(this.clearFormButton);
            this.Controls.Add(this.displaySummaryButton);
            this.Controls.Add(this.orderDetailsGroupBox);
            this.Controls.Add(this.deliveryInfoGroupBox);
            this.Controls.Add(this.customerInfoGroupBox);
            this.Controls.Add(this.companyNameLabel);
            this.Controls.Add(this.balloonsPictureBox);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Balloon Order Application";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.balloonsPictureBox)).EndInit();
            this.customerInfoGroupBox.ResumeLayout(false);
            this.customerInfoGroupBox.PerformLayout();
            this.deliveryInfoGroupBox.ResumeLayout(false);
            this.deliveryInfoGroupBox.PerformLayout();
            this.orderDetailsGroupBox.ResumeLayout(false);
            this.orderDetailsGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox balloonsPictureBox;
        private System.Windows.Forms.Label companyNameLabel;
        private System.Windows.Forms.GroupBox customerInfoGroupBox;
        private System.Windows.Forms.GroupBox deliveryInfoGroupBox;
        private System.Windows.Forms.GroupBox orderDetailsGroupBox;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label streetLabel;
        private System.Windows.Forms.Label phoneNumberLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.MaskedTextBox phoneNumberMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox zipCodeMaskedTextBox;
        private System.Windows.Forms.Label zipCodeLabel;
        private System.Windows.Forms.Label stateLabel;
        private System.Windows.Forms.Label cityLabel;
        private System.Windows.Forms.ComboBox titleComboBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox streetTextBox;
        private System.Windows.Forms.MaskedTextBox stateMaskedTextBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.Label deliveryDateLabel;
        private System.Windows.Forms.MaskedTextBox deliveryDateMaskedTextBox;
        private System.Windows.Forms.RadioButton homeDeliveryRadioButton;
        private System.Windows.Forms.RadioButton storePickUpRadioButton;
        private System.Windows.Forms.Label deliveryTypeLabel;
        private System.Windows.Forms.Label homeDeliveryUpchargeLabel;
        private System.Windows.Forms.RadioButton singleBundleRadioButton;
        private System.Windows.Forms.Label bundleSizeLabel;
        private System.Windows.Forms.Label singleBundleCostLabel;
        private System.Windows.Forms.RadioButton halfDozenBundleRadioButton;
        private System.Windows.Forms.RadioButton dozenBundleRadioButton;
        private System.Windows.Forms.Label dozenBundleCostLabel;
        private System.Windows.Forms.Label halfDozenBundleCostLabel;
        private System.Windows.Forms.Label specialOccasionLabel;
        private System.Windows.Forms.ComboBox specialOccasionComboBox;
        private System.Windows.Forms.Label extrasLabel;
        private System.Windows.Forms.ListBox extrasListBox;
        private System.Windows.Forms.CheckBox personalizedMessageCheckBox;
        private System.Windows.Forms.Label personalizedMessageLabel;
        private System.Windows.Forms.Label personalizedMessagePriceLabel;
        private System.Windows.Forms.Label personalizedMessageInstructionLabel;
        private System.Windows.Forms.TextBox personalizedMessageTextBox;
        private System.Windows.Forms.Label boxOfChocolatesPriceLabel;
        private System.Windows.Forms.Label orderSubtotalLabel;
        private System.Windows.Forms.Label orderSubtotalLblLabel;
        private System.Windows.Forms.Label salesTaxAmountLblLabel;
        private System.Windows.Forms.Label orderTotalLblLabel;
        private System.Windows.Forms.Label salesTaxAmountLabel;
        private System.Windows.Forms.Label orderTotalLabel;
        private System.Windows.Forms.Label taxRateLabel;
        private System.Windows.Forms.Button displaySummaryButton;
        private System.Windows.Forms.Button clearFormButton;
        private System.Windows.Forms.Button exitProgramButton;
        private System.Windows.Forms.Label coffeeMugPriceLabel;
        private System.Windows.Forms.Label flowerArrangementPriceLabel;
        private System.Windows.Forms.Label jarOfJellyBeansPriceLabel;
        private System.Windows.Forms.Label pottedPlantPriceLabel;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

